import json
import re

import scrapy
from mymodules_new._common_ import c_replace

from linkbricks.config import *
from linkbricks.pipelines import *
class LBricksSpider(scrapy.Spider):
    name = 'main'
    F_PATH = html_path
    handle_httpstatus_list = [400, 500, 401]

    def __init__(self, start='', end=''):
        self.cursor = LinkbricksPipeline.cursor
        self.con = LinkbricksPipeline.con
        self.start = start
        self.end = end
        self.currency = currency


    def start_requests(self):
        try:
            competition_flag = False
            id = "",
            sku_id = ""
            sku_name = ""
            # sql_ = f'''SELECT Id,url,`Product Name` FROM {maintable_name} where status='done' and `Discounted Price` = ''  and id between {self.start} and {self.end}'''
            sql_ = f'''SELECT Id,url,`Product Name` FROM {maintable_name}  WHERE STATUS='Done' AND `Rating Count by star-1` = '' and id between {self.start} and {self.end}'''
            self.cursor.execute(sql_)
            core_list  = self.cursor.fetchall()
            for row in core_list:
                id = row[0]
                sku_url = row[1]
                sku_name = row[2]

                data_filename = f'/{region}_{id}_data.html'
                path = self.F_PATH + data_filename
                path = path.replace("\\", "/")

                meta_dict = {
                    "id": id,
                    "sku_url": sku_url,
                    "maintable_name": maintable_name,
                    "path": path,
                    "currency": self.currency,
                    "sku_name": sku_name,

                }

                if os.path.exists(path):
                    path = path.replace("/", "\\")
                    path = path.replace("\\\\", "\\")
                    yield scrapy.FormRequest(url=f'file:{path}', callback=self.parse,meta={"meta_dict": meta_dict})
                else:
                    print(sku_url)
                    page_status = upright_main(sku_url,path)
                    if page_status is True:
                        path = path.replace("/", "\\")
                        path = path.replace("\\\\", "\\")
                        yield scrapy.FormRequest(url=f'file:{path}', callback=self.parse,meta={"meta_dict": meta_dict})

        except Exception as e:
            logger.error('start requests method error in main2--: {}'.format(e))

    def parse(self, response,**kwargs):
        try:
            main_data = response.text
            print("Going In parse----- ")
            item = LinkbricksItem()
            meta_dict = response.meta.get('meta_dict')
            id = meta_dict.get('id')
            currency = meta_dict.get('currency')
            path = meta_dict.get('path')
            maintable_name = meta_dict.get('maintable_name')
            sku_url = meta_dict.get('sku_url')
            sku_name = meta_dict.get('sku_name')
            path = meta_dict.get('path')

            # todo - price
            try:
                price = response.xpath('''//div[contains(@class, 'product-price')]//span[contains(@class, 'pdp-price')]//text()''').getall()
                if price:
                    if len(price) == 2:
                        discounted_price = price[0]
                        original_Price = price[1]
                    else:
                        discounted_price = "0"
                        original_Price = price[0]
                else:
                    discounted_price = "0"
                    original_Price = "0"
                    print("Price not found--- ")
                if discounted_price:
                    discounted_price = re.sub("[^.0-9]", "", discounted_price)
                    # if '.00' in discounted_price:
                    #     discounted_price = str(discounted_price).split(".")[0]
                    # else:
                    #     discounted_price = discounted_price

                if original_Price:
                    original_Price = re.sub("[^.0-9]", "", original_Price)
                    # if '.00' in original_Price:
                    #     original_Price = str(original_Price).split(".")[0]
                    # else:
                    #     original_Price = original_Price
                item['`discounted price`'] = c_replace(str(discounted_price))
                item['`original Price`'] = c_replace(str(original_Price))
            except Exception as e:
                discounted_price = ""
                original_Price = ""
                item['discounted price'] = c_replace(str(discounted_price))
                item['original Price'] = c_replace(str(original_Price))
                print("Error  in price---- ", e)

            #todo Category
            try:
                Category = response.xpath('''//ul[@class="breadcrumb"]/li//text()''').getall()
                if Category:
                    Category = Category[0:3]
                    Category = ' > '.join(Category)
                else:
                    Category = ""
                item['Category'] = c_replace(str(Category))
            except Exception as e:
                print("Error in Category---> ", e)
                return None

            # todo all_star
            try:
                all_star = response.xpath('''//div[@class="detail"]//text()''').getall()
                if all_star:
                    five_star = all_star[0]
                    four_star = all_star[1]
                    three_star = all_star[2]
                    two_star = all_star[3]
                    one_star = all_star[4]
                else:
                    five_star = '0'
                    four_star = '0'
                    three_star = '0'
                    two_star = '0'
                    one_star = '0'
                item['`Rating Count by Star-5`'] = c_replace(str(five_star))
                item['`Rating Count by Star-4`'] = c_replace(str(four_star))
                item['`Rating Count by Star-3`'] = c_replace(str(three_star))
                item['`Rating Count by Star-2`'] = c_replace(str(two_star))
                item['`Rating Count by Star-1`'] = c_replace(str(one_star))
            except Exception as e:
                print("Error in all_star---> ", e)
                return None

            #todo total_raing_count
            try:
                total_raing_count = response.xpath('//a[contains(text(),"Ratings")]/text()').get()
                if total_raing_count:
                    total_raing_count = str(total_raing_count).split()[0]
                else:
                    total_raing_count = "0"
                item['`Total Raing Count`'] = c_replace(str(total_raing_count))
            except Exception as e:
                print("Error in total_raing_count---> ", e)
                return None

            # todo rating_score
            try:
                rating_score = response.xpath('//span[@class="score-average"]/text()').get()
                if rating_score:
                    rating_score = rating_score
                else:
                    rating_score = '0'
                item['`Rating Score`'] = c_replace(str(rating_score))
            except Exception as e:
                print("Error in rating_score---> ", e)
                return None

            # todo item_id
            try:
                buyparams = response.xpath('//div[@id="module_add_to_cart"]//input[@name="buyParams"]/@value').get()
                if buyparams:
                    jdata = json.loads(buyparams)
                    item_id = jdata['items'][0]['itemId']
                    buyparams = item_id
                else:
                    buyparams = str(sku_url).split('-i')[1].replace('.html','')
                item['item_id'] = c_replace(str(buyparams))
            except Exception as e:
                print("Error in item_id---> ", e)
                return None
            item['HtmlPath'] = path
            item['Status'] = 'done'
            item['Id'] = str(id)
            LinkbricksPipeline.update_item(self, item)
        except Exception as e:
            logger.error('PARSE METHOD method error in main2--: {}'.format(e))
if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl main -a start=1 -a end=37700'.split())