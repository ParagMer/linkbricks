import random

import requests

item_id = '213590271'
# url = f'https://my.lazada.co.id/pdp/review/getReviewList?itemId={item_id}&pageSize=5&filter=0&sort=0&pageNo=1'
url = f'https://my.lazada.com.ph/pdp/review/getReviewList?itemId=213590271&pageSize=5&filter=0&sort=0&pageNo=1'
with open('UserAgent.txt', 'r', encoding='utf8') as f:
    useragent = f.read()
    useragent = useragent.splitlines()
    useragent = random.choice(useragent)
head = {
    'authority': 'www.lazada.co.id',
    'method': 'GET',
    'path': '/products/cosrx-aha-7-whitehead-power-liquid-25ml-share-in-bottle-travel-size-i1491924200.html',
    'scheme': 'https',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'cookie': '_uab_collina=166903378937850167063008; __wpkreporterwid_=521a6916-eed7-4741-1d70-f457c7c0ea22; hng=ID|id-ID|IDR|360; hng.sig=to18pG508Hzz7EPB_okhuQu8kDUP3TDmLlnu4IbIOY8; EGG_SESS=S_Gs1wHo9OvRHCMp98md7DjcNzB9C_dJvTyPV3wsRrJ8MDgMteoY-p8Ob_cisCeHhwCE8s6oEbDCiNN6bTelu9hXnGhgCJPWmqxsDOHKQuykOQCRVFYlrXqhY1SooMs2TMfFv0w2YVLoLjHZTYzV6lJfxjuNA5asPAO_3kbjyGI=; lzd_cid=d279c363-7bff-49cb-8597-df9aa77c0f45; t_uid=d279c363-7bff-49cb-8597-df9aa77c0f45; t_fv=1669033789249; t_sid=o3vncuh0SFg4paU49mC3dOAqpC77L5PQ; utm_channel=NA; cna=PV0CHPWynCgCAcElIC3w9oAW; _m_h5_tk=20c3e5bdaef506ee16dccb9955bfe748_1669042430294; _m_h5_tk_enc=0a182a01fb0add7baa81f767817b328e; lzd_sid=1a337dbba422a15faf71e721d80288c0; _tb_token_=e3d9aeebbee5f; _bl_uid=kblk2a97qn5ryRmwhiItxwh03bCI; xlly_s=1; isg=BFdXdrRB-NWFAXxZ9om9eWNP5suhnCv-G1Hm_6mG0Sbv2HQaq2zIT6WyOmBGMAN2; tfstk=cRmVBbmRUnK2lMH99uqZY9uMeUOAa5MmIgyQoCf_vWkJyUrzTsqR68YHZ8y1U14c.; l=eBEPUOmeTcqAcgxBBO5Zhurza779FQRf1sPzaNbMiInca6iPadjSMNCUSfmpudtjQtfUa3xzmSrNYdCLO3ad_v9wNhNnuZHe0Ypw-',
    'upgrade-insecure-requests': '1',
    'user-agent': useragent,
}
review_req = requests.get(url=url, headers=head)
print(review_req.text)

