import os
import random
import sys
import time
from datetime import datetime

import requests
from playwright.sync_api import Playwright, sync_playwright

import clr


today_date = datetime.now().strftime('%Y_%m_%d')
table_date = datetime.now().strftime('%Y%m%d')
timestamp = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
with open('E:\Parag_Mer\Working\linkbricks\linkbricks\lazada_parag.txt', 'r') as f:
    file = f.read()
file = file.split('\n')

db_host = '192.168.1.66'
db_user = 'root'
db_passwd = 'xbyte'
db_name = file[0].replace('db_name = ','')

maintable_name = file[1].replace('tablename = ','')
review_table = 'reviewdata_2022_11_14'
if "_id" in db_name.lower():
    region = "ID"
    currency = "Rp"
    domain = "https://www.lazada.co.id/products"
elif "_my" in db_name.lower():
    region = "MY"
    currency = "RM"
    domain = "https://www.lazada.com.my/products"
elif "_ph" in db_name.lower():
    region = "PH"
    currency = "₱"
    domain = "https://www.lazada.com.ph/products"
elif "_sg" in db_name.lower():
    region = "SG"
    currency = "$"
    domain = "https://www.lazada.sg/products"
elif "_th" in db_name.lower():
    region = "TH"
    currency = "฿"
    domain = "https://www.lazada.co.th/products"
elif "_vn" in db_name.lower():
    region = "VN"
    currency = "₫"
    domain = "https://www.lazada.vn/products"
else:
    region = ""
    print("Error in region splitting............................")
    time.sleep(100000)

html_path = f'\\\\192.168.1.127\\D\\Daily Scheduler\\0. P&G\\png_lazada_drop\\Htmls_{region}\\HTML\\{today_date}'
Log = html_path + '\\Log'

if not os.path.exists(html_path):
    os.makedirs(html_path)
if not os.path.exists(Log):
    os.makedirs(Log)

import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.setLevel(logging.ERROR)
logger.setLevel(logging.WARNING)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
file_handler = logging.FileHandler(Log+f'\\lazada_png_{today_date}.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

def upright_main(sku_url,path):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(channel="msedge", headless=False, slow_mo=50)
            page = browser.new_page()
            page.set_default_timeout(0)

            page.goto(sku_url)
            for i in range(5):  # make the range as long as needed
                page.mouse.wheel(0, 500)
                time.sleep(1)
                i += 1

            response_txt = page.content()

            try:
                if "var __moduleData__" in response_txt:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(page.content())

                if os.path.exists(path):
                    with open(path, 'r',encoding='utf-8' ) as f:
                        page = f.read()
            except Exception as e:
                print(e)

            browser.close()

            if "__moduleData__" in page:
                return True
            else:
                return False

    except Exception as e:
        print("Error in sel fun....-- ",e)

def post_url(url):
    with open('UserAgent.txt', 'r', encoding='utf8') as f:
        useragent = f.read()
        useragent = useragent.splitlines()
        useragent = random.choice(useragent)
    head = {
        'authority': 'www.lazada.co.id',
        'method': 'GET',
        'path': '/products/cosrx-aha-7-whitehead-power-liquid-25ml-share-in-bottle-travel-size-i1491924200.html',
        'scheme': 'https',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'cookie': '_uab_collina=166903378937850167063008; __wpkreporterwid_=521a6916-eed7-4741-1d70-f457c7c0ea22; hng=ID|id-ID|IDR|360; hng.sig=to18pG508Hzz7EPB_okhuQu8kDUP3TDmLlnu4IbIOY8; EGG_SESS=S_Gs1wHo9OvRHCMp98md7DjcNzB9C_dJvTyPV3wsRrJ8MDgMteoY-p8Ob_cisCeHhwCE8s6oEbDCiNN6bTelu9hXnGhgCJPWmqxsDOHKQuykOQCRVFYlrXqhY1SooMs2TMfFv0w2YVLoLjHZTYzV6lJfxjuNA5asPAO_3kbjyGI=; lzd_cid=d279c363-7bff-49cb-8597-df9aa77c0f45; t_uid=d279c363-7bff-49cb-8597-df9aa77c0f45; t_fv=1669033789249; t_sid=o3vncuh0SFg4paU49mC3dOAqpC77L5PQ; utm_channel=NA; cna=PV0CHPWynCgCAcElIC3w9oAW; _m_h5_tk=20c3e5bdaef506ee16dccb9955bfe748_1669042430294; _m_h5_tk_enc=0a182a01fb0add7baa81f767817b328e; lzd_sid=1a337dbba422a15faf71e721d80288c0; _tb_token_=e3d9aeebbee5f; _bl_uid=kblk2a97qn5ryRmwhiItxwh03bCI; xlly_s=1; isg=BFdXdrRB-NWFAXxZ9om9eWNP5suhnCv-G1Hm_6mG0Sbv2HQaq2zIT6WyOmBGMAN2; tfstk=cRmVBbmRUnK2lMH99uqZY9uMeUOAa5MmIgyQoCf_vWkJyUrzTsqR68YHZ8y1U14c.; l=eBEPUOmeTcqAcgxBBO5Zhurza779FQRf1sPzaNbMiInca6iPadjSMNCUSfmpudtjQtfUa3xzmSrNYdCLO3ad_v9wNhNnuZHe0Ypw-',
        'upgrade-insecure-requests': '1',
        'user-agent': useragent,
    }
    review_req = requests.get(url=url,headers=head)
    return review_req