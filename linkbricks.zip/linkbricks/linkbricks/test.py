# # todo reviews
# try:
#     review = response.xpath('//div[@class="mod-reviews"]//div[@class="item"]')
#     if review:
#         for j in review:
#             # todo review_write_date_time
#             try:
#                 r_write_date_time = j.xpath('.//span[@class="title right"]/text()').get()
#                 if r_write_date_time:
#                     r_write_date_time = r_write_date_time.lower()
#                     m = r_write_date_time.split()[1]
#                     months = {
#                         'jan': 1,
#                         'feb': 2,
#                         'mar': 3,
#                         'apr': 4,
#                         'may': 5,
#                         'jun': 6,
#                         'jul': 7,
#                         'aug': 8,
#                         'sep': 9,
#                         'oct': 10,
#                         'nov': 11,
#                         'dec': 12,
#                     }
#                     mon = months[m]
#                     date = r_write_date_time.split()[0]
#                     year = r_write_date_time.split()[2]
#                     start_date = year + '_' + str(mon) + '_' + date
#                     t_date = today_date
#                     d1 = datetime.strptime(start_date, "%Y_%m_%d")
#                     d2 = datetime.strptime(today_date, "%Y_%m_%d")
#
#                     # difference between dates in timedelta
#                     delta = d2 - d1
#                     if delta.days <= 90:
#                         item['`Review WRITE DATE time`'] = c_replace(str(r_write_date_time))
#                         # todo review_username
#                         try:
#                             r_username = j.xpath('.//div[@class="middle"]/span//text()').get()
#                             if r_username:
#                                 r_username = r_username
#                             else:
#                                 r_username = ''
#                             item['UserName'] = c_replace(str(r_username))
#                         except Exception as e:
#                             print('Error in review_username:-', e)
#                         # todo review_Verified_Purchase
#                         try:
#                             r_Verified_Purchase = j.xpath('.//span[@class="verify"]/text()').get()
#                             if r_Verified_Purchase:
#                                 if 'Pembelian' in r_Verified_Purchase:
#                                     r_Verified_Purchase = '1'
#                                 else:
#                                     r_Verified_Purchase = '0'
#                             else:
#                                 r_Verified_Purchase = '0'
#                             item['`Verified Purchase`'] = c_replace(str(r_Verified_Purchase))
#                         except Exception as e:
#                             print('Error in r_Verified_Purchase:-', e)
#                         # todo review_stars
#                         try:
#                             # r_stars = response.xpath('.//div[@class="container-star starCtn left"]/img').get()
#                             r_stars = '5'
#                             if r_stars:
#                                 r_stars = r_stars
#                             else:
#                                 r_stars = ''
#                             item['`Review STARTS`'] = c_replace(str(r_stars))
#                         except Exception as e:
#                             print('Error in review_stars:-', e)
#                         # todo review_Product_OPTION
#                         try:
#                             r_Product_OPTION = j.xpath('.//div[@class="skuInfo"]/text()').get()
#                             if r_Product_OPTION:
#                                 r_Product_OPTION = r_Product_OPTION
#                             else:
#                                 r_Product_OPTION = ''
#                             item['`Review Product OPTION`'] = c_replace(str(r_Product_OPTION))
#                         except Exception as e:
#                             print('Error in r_Review_Product_OPTION:-', e)
#                         # todo review_Vote_Count
#                         try:
#                             r_Vote_Count = j.xpath('.//span[@class="left-content"]//span/text()').get()
#                             if r_Vote_Count:
#                                 r_Vote_Count = r_Vote_Count
#                             else:
#                                 r_Vote_Count = ''
#                             item['`Review Vote Count`'] = c_replace(str(r_Vote_Count))
#                         except Exception as e:
#                             print('Error in r_Review_Vote_Count:-', e)
#                         # todo review_Review_Image_URL
#                         try:
#                             r_Image_URL = j.xpath('.//div[@class="image"]/@style').get()
#                             if r_Image_URL:
#                                 r_Image_URL = r_Image_URL.split('''url("''')[1].replace('");', '')
#                                 r_Image_URL = r_Image_URL
#                             else:
#                                 r_Image_URL = ''
#                             item['`Review Image URL`'] = c_replace(str(r_Image_URL))
#                         except Exception as e:
#                             print('Error in r_Review_Image_URL:-', e)
#                         # todo review_contents
#                         try:
#                             r_contents = j.xpath('.//div[@class="content"]/text()').get()
#                             if r_contents:
#                                 r_contents = r_contents
#                             else:
#                                 r_contents = ''
#                             item['`Review contents`'] = c_replace(str(r_contents))
#
#                         except Exception as e:
#                             print('Error in review_contents:-', e)
#                         item['Timestamp'] = timestamp
#                         item['HtmlPath'] = path
#                         item['Status'] = 'done'
#                         item['Id1'] = str(id)
#                         item['`Product URL`'] = sku_url
#                         item['`Product Name`'] = sku_name
#                         LinkbricksPipeline.process_item(self, item)
#                     else:
#                         print('more than 3months')
#                 else:
#                     continue
#             except Exception as e:
#                 print('Error in r_write_date_time:-', e)
#
#     else:
#         item['Timestamp'] = timestamp
#         item['HtmlPath'] = path
#         item['Status'] = 'Not Found'
#         item['Id1'] = str(id)
#         item['`Product URL`'] = sku_url
#         item['`Product Name`'] = sku_name
#         LinkbricksPipeline.process_item(self, item)
#
# except Exception as e:
#     print('Error in reviews:-',e)
