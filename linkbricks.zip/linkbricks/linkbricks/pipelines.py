# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from linkbricks.config import *
from linkbricks.items import *

class LinkbricksPipeline:
    try:
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
        db_cursor = con.cursor()

        create_db = f"create database if not exists `{db_name}`"
        db_cursor.execute(create_db)

        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=True,
                              use_unicode=True, charset="utf8")
        cursor = con.cursor()
        print("Database Connection success....")
    except Exception as e:
        print("Erroor in pipeline ---- ", e)

    def update_item(self, item):
        if isinstance(item, LinkbricksItem):
            try:
                make_update_query = f'update `{maintable_name}` set '
                for key, value in item.items():
                    if isinstance(value, str):
                        make_update_query += key + "=" + '"' + value.replace('"', "’") + '"' + ","
                    else:
                        make_update_query += key + "=" + '"' + value + '"' + ","

                Id = item['Id']

                update_query = f'{make_update_query} where Id={Id}'.replace(', where Id=',' where Id=')
                LinkbricksPipeline.cursor.execute(update_query)
                LinkbricksPipeline.con.commit()
                print(f"|-----------------------------------------{Id} is updated----------------------------------------------------|")
            except Exception as e:
                print(e)

    def process_item(self, item, spider):
        if isinstance(item, LinkbricksItem):
            try:
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))
                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = "INSERT INTO " + review_table + "( " + fields + " ) values ( '" + values + "' )"
                print("|--------------------------------------------------------------------------------------------------|")
                self.cursor.execute(insert_db)
                self.con.commit()

            except Exception as e:
                logger.error("Exception in process_item method : {}".format(e))
                print('pipeline process item', e, item['product_url'])
                logger.error(
                    "exception in process_item method in insert data url is:{}:{}".format(e, item['product_url']))
                return None
