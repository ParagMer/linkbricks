import pymysql
import numpy as np
from linkbricks.config import *
spider_name = "main"
file_name = "main_bat.bat"
part_count = 10

from datetime import datetime
table_date = datetime.now().strftime('%Y%m%d')

with open('E:\Parag_Mer\Working\linkbricks\linkbricks\lazada_parag.txt','r') as f:
    file = f.read()
file = file.split('\n')



database = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name)
cursor = database.cursor()

sql_query=f'''SELECT * FROM {maintable_name} where status='done' and `Original Price` = '' '''

cursor.execute(sql_query)
results = cursor.fetchall()
rows = len(results)
check = rows/int(part_count)
core_list = [column for column in results]
C_ids = []
for itm in core_list:
    id = itm[0]
    C_ids.append(id)
temp=0
l = len(C_ids)

# n = int(input("Enter the Part:"))
n = part_count
d=round(l/n)
x_ids =np.array_split(C_ids,n)

path = 'E:\Parag_Mer\Working\linkbricks\linkbricks\spiders\main_bat.bat'
try:
    with open(path, 'r+') as f1:
        f1.truncate()
except Exception as  e:
    print(e)


for parts in x_ids:
    with open(path,'a') as f:
        f.write(f'start scrapy crawl {spider_name} -a start={parts[0]} -a end={parts[-1]}')
        f.write('\n')
        f.close()